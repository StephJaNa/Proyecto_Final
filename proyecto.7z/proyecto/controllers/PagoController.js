const PagoDAO = require('../daos/PagoDAO');

class PagoController {
    static async getAllPagos(req, res) {
        try {
            const pagos = await PagoDAO.getAllPagos();
            res.json(pagos);
        } catch (err) {
            res.status(500).json({ error: err.message });
        }
    }

    // Agregar más métodos controladores según sea necesario
}

module.exports = PagoController;
