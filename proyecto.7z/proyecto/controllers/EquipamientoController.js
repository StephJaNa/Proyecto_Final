const EquipamientoDAO = require('../daos/EquipamientoDAO');

class EquipamientoController {
    static async getAllEquipamientos(req, res) {
        try {
            const equipamientos = await EquipamientoDAO.getAllEquipamientos();
            res.json(equipamientos);
        } catch (err) {
            res.status(500).json({ error: err.message });
        }
    }

    
}

module.exports = EquipamientoController;
