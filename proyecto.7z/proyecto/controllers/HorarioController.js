const HorarioDAO = require('../daos/HorarioDAO');

class HorarioController {
    static async getAllHorarios(req, res) {
        try {
            const horarios = await HorarioDAO.getAllHorarios();
            res.json(horarios);
        } catch (err) {
            res.status(500).json({ error: err.message });
        }
    }

    // Agregar más métodos controladores según sea necesario
}

module.exports = HorarioController;
