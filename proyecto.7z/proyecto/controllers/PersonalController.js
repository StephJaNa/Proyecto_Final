const PersonalDAO = require('../daos/PersonalDAO');

class PersonalController {
    static async getAllPersonal(req, res) {
        try {
            const personal = await PersonalDAO.getAllPersonal();
            res.json(personal);
        } catch (err) {
            res.status(500).json({ error: err.message });
        }
    }

    // Agregar más métodos controladores según sea necesario
}

module.exports = PersonalController;
