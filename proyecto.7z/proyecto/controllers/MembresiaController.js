const MembresiaDAO = require('../daos/MembresiaDAO');

class MembresiaController {
    static async getAllMembresias(req, res) {
        try {
            const membresias = await MembresiaDAO.getAllMembresias();
            res.json(membresias);
        } catch (err) {
            res.status(500).json({ error: err.message });
        }
    }

    // Agregar más métodos controladores según sea necesario
}

module.exports = MembresiaController;
