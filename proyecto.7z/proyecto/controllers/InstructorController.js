const InstructorDAO = require('../daos/InstructorDAO');

class InstructorController {
    static async getAllInstructores(req, res) {
        try {
            const instructores = await InstructorDAO.getAllInstructores();
            res.json(instructores);
        } catch (err) {
            res.status(500).json({ error: err.message });
        }
    }

    // Agregar más métodos controladores según sea necesario
}

module.exports = InstructorController;
