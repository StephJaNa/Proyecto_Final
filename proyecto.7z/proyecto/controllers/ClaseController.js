const ClaseDAO = require('../daos/ClaseDAO');

class ClaseController {
    static async getAllClases(req, res) {
        try {
            const clases = await ClaseDAO.getAllClases();
            res.json(clases);
        } catch (err) {
            res.status(500).json({ error: err.message });
        }
    }

    
}

module.exports = ClaseController;
