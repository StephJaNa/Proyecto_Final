const ClienteDAO = require('../daos/ClienteDAO');

class ClienteController {
    static async getAllClientes(req, res) {
        try {
            const clientes = await ClienteDAO.getAllClientes();
            res.json(clientes);
        } catch (err) {
            res.status(500).json({ error: err.message });
        }
    }

   
}

module.exports = ClienteController;
