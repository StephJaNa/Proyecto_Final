const InformacionDAO = require('../daos/InformacionDAO');

class InformacionController {
    static async getAllInformaciones(req, res) {
        try {
            const informaciones = await InformacionDAO.getAllInformaciones();
            res.json(informaciones);
        } catch (err) {
            res.status(500).json({ error: err.message });
        }
    }

    // Agregar más métodos controladores según sea necesario
}

module.exports = InformacionController;
