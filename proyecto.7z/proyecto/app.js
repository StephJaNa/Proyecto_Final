const express = require('express');
const app = express();
const ClienteController = require('./controllers/ClienteController');
const PersonalController = require('./controllers/PersonalController');
const InstructorController = require('./controllers/InstructorController');
const ClaseController = require('./controllers/ClaseController');
const HorarioController = require('./controllers/HorarioController');
const PagoController = require('./controllers/PagoController');
const EquipamientoController = require('./controllers/EquipamientoController');
const InformacionController = require('./controllers/InformacionController');
const MembresiaController = require('./controllers/MembresiaController');

// Middleware para aceptar url codificados
app.use(express.urlencoded({ extended: true }));

// Rutas para clientes
app.get('/clientes', ClienteController.getAllClientes);

// Rutas para personal
app.get('/personal', PersonalController.getAllPersonal);

// Rutas para instructores
app.get('/instructores', InstructorController.getAllInstructores);

// Rutas para clases
app.get('/clases', ClaseController.getAllClases);

// Rutas para horarios
app.get('/horarios', HorarioController.getAllHorarios);

// Rutas para pagos
app.get('/pagos', PagoController.getAllPagos);

// Rutas para equipamiento
app.get('/equipamientos', EquipamientoController.getAllEquipamientos);

// Rutas para información
app.get('/informaciones', InformacionController.getAllInformaciones);

// Rutas para membresías
app.get('/membresias', MembresiaController.getAllMembresias);

// Puerto de escucha
app.listen(3000, () => {
    console.log('Servidor en ejecución en el puerto 3000');
});
