const { MongoClient } = require('mongodb');

class MembresiaDAO {
    static async getAllMembresias() {
        const client = new MongoClient('mongodb://localhost:27017', { useUnifiedTopology: true });
        await client.connect();

        const db = client.db('proyecto');
        const collection = db.collection('Memberships');

        const membresias = await collection.find().toArray();

        client.close();

        return membresias;
    }

    // Agregar más métodos DAO según sea necesario
}

module.exports = MembresiaDAO;
