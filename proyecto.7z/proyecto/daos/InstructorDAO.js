const { MongoClient } = require('mongodb');

class InstructorDAO {
    static async getAllInstructores() {
        const client = new MongoClient('mongodb://localhost:27017', { useUnifiedTopology: true });
        await client.connect();

        const db = client.db('proyecto');
        const collection = db.collection('Instructores');

        const instructores = await collection.find().toArray();

        client.close();

        return instructores;
    }

    // Agregar más métodos DAO según sea necesario
}

module.exports = InstructorDAO;
