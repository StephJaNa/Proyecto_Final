const { MongoClient } = require('mongodb');

class HorarioDAO {
    static async getAllHorarios() {
        const client = new MongoClient('mongodb://localhost:27017', { useUnifiedTopology: true });
        await client.connect();

        const db = client.db('proyecto');
        const collection = db.collection('Schedules');

        const horarios = await collection.find().toArray();

        client.close();

        return horarios;
    }

    // Agregar más métodos DAO según sea necesario
}

module.exports = HorarioDAO;
