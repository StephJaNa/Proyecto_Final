const { MongoClient } = require('mongodb');

class InformacionDAO {
    static async getAllInformaciones() {
        const client = new MongoClient('mongodb://localhost:27017', { useUnifiedTopology: true });
        await client.connect();

        const db = client.db('proyecto');
        const collection = db.collection('Pilates_Information');

        const informaciones = await collection.find().toArray();

        client.close();

        return informaciones;
    }

    // Agregar más métodos DAO según sea necesario
}

module.exports = InformacionDAO;
