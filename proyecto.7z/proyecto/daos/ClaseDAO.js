const { MongoClient } = require('mongodb');

class ClaseDAO {
    static async getAllClases() {
        const client = new MongoClient('mongodb://localhost:27017', { useUnifiedTopology: true });
        await client.connect();

        const db = client.db('proyecto');
        const collection = db.collection('Classes');

        const clases = await collection.find().toArray();

        client.close();

        return clases;
    }

    // Agregar más métodos DAO según sea necesario
}

module.exports = ClaseDAO;
