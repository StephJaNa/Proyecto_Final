const { MongoClient } = require('mongodb');

class PersonalDAO {
    static async getAllPersonal() {
        const client = new MongoClient('mongodb://localhost:27017', { useUnifiedTopology: true });
        await client.connect();

        const db = client.db('proyecto');
        const collection = db.collection('Staff');

        const personal = await collection.find().toArray();

        client.close();

        return personal;
    }

    // Agregar más métodos DAO según sea necesario
}

module.exports = PersonalDAO;
